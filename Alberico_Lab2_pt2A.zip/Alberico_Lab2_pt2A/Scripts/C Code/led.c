all:
 arm-linux-gnueabihf-gcc -Dsoc_cv_av -O2 -o led led.c
 arm-linux-gnueabihf-strip -s led

clean:
 rm -rf led